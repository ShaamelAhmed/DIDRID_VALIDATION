from pathlib import Path
import sys
sys.path.append(str(Path(__file__).resolve().parent))
import argparse
import json
import time
from datetime import datetime, timezone
from urllib import request
from urllib.error import HTTPError, URLError
from common import load_json, save_json, append_csv, ensure_dir


def post_json(url, payload, timeout):
    data = json.dumps(payload).encode('utf-8')
    req = request.Request(url, data=data, headers={'Content-Type': 'application/json'})
    with request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode('utf-8'))


def compare(actual, expected, mode):
    actual = '' if actual is None else str(actual)
    expected = '' if expected is None else str(expected)
    if mode == 'exact':
        return actual == expected
    if mode == 'nonempty':
        return bool(actual.strip())
    return expected in actual


def run_all(profile):
    base = profile['adapter']['base_url'].rstrip('/')
    timeout = profile['adapter'].get('timeout_seconds', 15)
    did_results, rid_results = [], []
    for test in profile['did_tests']:
        started = time.time()
        resp = post_json(base + '/did/read', {'did': test['identifier']}, timeout)
        actual = resp.get('parsed_response') or resp.get('raw_response')
        ok = resp.get('ok', False) and compare(actual, test['expected'], test.get('compare', 'contains'))
        did_results.append({
            'name': test['name'], 'identifier': test['identifier'], 'expected': test['expected'],
            'actual': actual, 'status': 'PASS' if ok else 'FAIL', 'transport': resp.get('transport'),
            'duration_ms': round((time.time() - started) * 1000, 1), 'notes': resp.get('notes', '')
        })
    for test in profile['rid_tests']:
        started = time.time()
        resp = post_json(base + '/rid/run', {'rid': test['identifier'], 'action': test.get('action', 'start')}, timeout)
        actual = resp.get('parsed_response') or resp.get('raw_response')
        ok = resp.get('ok', False) and compare(actual, test['expected'], test.get('compare', 'contains'))
        rid_results.append({
            'name': test['name'], 'identifier': test['identifier'], 'expected': test['expected'],
            'actual': actual, 'status': 'PASS' if ok else 'FAIL', 'transport': resp.get('transport'),
            'duration_ms': round((time.time() - started) * 1000, 1), 'notes': resp.get('notes', '')
        })
    return {'did_results': did_results, 'rid_results': rid_results}


def classify(results):
    if any(r['status'] != 'PASS' for r in results['did_results']):
        return 'FAIL_DID'
    if any(r['status'] != 'PASS' for r in results['rid_results']):
        return 'FAIL_RID'
    return 'PASS'


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--profile', required=True)
    ap.add_argument('--output-dir', required=True)
    args = ap.parse_args()
    profile = load_json(args.profile)
    out = ensure_dir(args.output_dir)
    ts = datetime.now(timezone.utc).isoformat().replace(':', '-')
    try:
        results = run_all(profile)
        final_status = classify(results)
    except (HTTPError, URLError, ConnectionError, TimeoutError) as e:
        results = {'did_results': [], 'rid_results': [], 'error': str(e)}
        final_status = 'BLOCKED'
    payload = {'timestamp_utc': ts, 'metadata': profile['metadata'], 'final_status': final_status, 'results': results}
    json_path = out / 'json' / f"{profile['metadata']['release_label'].replace(' ', '_')}_{profile['metadata']['ecu']}_{ts}.json"
    save_json(json_path, payload)
    append_csv(out / 'validator_summary.csv',
               ['timestamp_utc', 'release_label', 'ecu', 'software_version', 'final_status', 'json_path'],
               {
                   'timestamp_utc': ts,
                   'release_label': profile['metadata']['release_label'],
                   'ecu': profile['metadata']['ecu'],
                   'software_version': profile['metadata']['software_version'],
                   'final_status': final_status,
                   'json_path': str(json_path),
               })
    print(json.dumps({'final_status': final_status, 'json_path': str(json_path)}, indent=2))


if __name__ == '__main__':
    main()
