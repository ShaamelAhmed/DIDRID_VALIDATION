from pathlib import Path
import sys
sys.path.append(str(Path(__file__).resolve().parent))
import argparse
from common import load_json, save_json


def expected_value(test, summary):
    if test.get('expected_from') == 'release_label':
        return summary.get('release_label') or summary.get('release_version') or test.get('default_expected')
    if test.get('expected_from') == 'expected_ecu_state':
        return test.get('default_expected', 'READY')
    return test.get('default_expected')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--summary', required=True)
    ap.add_argument('--base-profile', default='profiles/base_profile.json')
    ap.add_argument('--test-catalog', default='config/test_catalog.json')
    ap.add_argument('--interface-map', default='config/interface_map.json')
    ap.add_argument('--output', required=True)
    ap.add_argument('--bench-id', default='TBD')
    ap.add_argument('--operator', default='TBD')
    args = ap.parse_args()

    summary = load_json(args.summary)
    profile = load_json(args.base_profile)
    catalog = load_json(args.test_catalog)
    interface_map = load_json(args.interface_map)

    profile['metadata'].update({
        'release_label': summary.get('release_label') or 'UNKNOWN',
        'release_version': summary.get('release_version') or 'UNKNOWN',
        'software_version': summary.get('software_version') or 'UNKNOWN',
        'ecu': summary.get('ecu') or 'UNKNOWN',
        'bench_id': args.bench_id,
        'operator': args.operator,
    })
    profile['delivery_summary'] = summary
    profile['interface_map'] = interface_map
    profile['did_tests'] = [
        {
            'name': t['name'],
            'identifier': t['identifier'],
            'mapping_key': t['name'],
            'compare': t['compare'],
            'expected': expected_value(t, summary),
        }
        for t in catalog['did_tests']
    ]
    profile['rid_tests'] = [
        {
            'name': t['name'],
            'identifier': t['identifier'],
            'mapping_key': t['name'],
            'compare': t['compare'],
            'expected': expected_value(t, summary),
            'action': 'start',
        }
        for t in catalog['rid_tests']
    ]

    save_json(args.output, profile)
    print(args.output)


if __name__ == '__main__':
    main()
