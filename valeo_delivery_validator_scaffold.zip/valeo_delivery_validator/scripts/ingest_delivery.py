from pathlib import Path
import sys
sys.path.append(str(Path(__file__).resolve().parent))
import argparse
import json
import re
import zipfile
from io import BytesIO
from common import save_json, ensure_dir

RELEASE_RE = re.compile(r'R\d{3}(?:\s+RS\d(?:\.\d)?)?')
VERSION_RE = re.compile(r'\b\d+\.\d+\.\d+\b')
PART_RE = re.compile(r'\b\d{8}\b')


def list_archive(path):
    with zipfile.ZipFile(path) as zf:
        return zf.namelist()


def find_workbook(path):
    for name in list_archive(path):
        if name.lower().endswith('.xlsx'):
            return name
    return None


def read_xlsx_strings(bundle_zip, workbook_name):
    if not workbook_name:
        return ''
    with zipfile.ZipFile(bundle_zip) as outer:
        data = outer.read(workbook_name)
    texts = []
    with zipfile.ZipFile(BytesIO(data)) as xlsx:
        for name in xlsx.namelist():
            if name.endswith('.xml') and ('sharedStrings' in name or 'sheet' in name or 'workbook' in name):
                texts.append(xlsx.read(name).decode('utf-8', errors='ignore'))
    return '\n'.join(texts)


def parse_bundle_name(path):
    name = Path(path).name
    ecu = None
    m = re.search(r'_(CCU[^_]+)_', name)
    if m:
        ecu = m.group(1)
    prod = None
    m = re.search(r'Prod_([0-9.]+)', name)
    if m:
        prod = m.group(1)
    return {'bundle_name': name, 'ecu': ecu, 'release_version': prod}


def extract_binary_parts(binary_bundle):
    parts, files = [], []
    for name in list_archive(binary_bundle):
        files.append(name)
        m = PART_RE.search(Path(name).stem)
        if m:
            parts.append(m.group(0))
    return sorted(set(parts)), files


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--binary-bundle', required=True)
    ap.add_argument('--ecu-info-bundle', required=True)
    ap.add_argument('--report-3pd-bundle', required=True)
    ap.add_argument('--output-dir', required=True)
    args = ap.parse_args()

    out = ensure_dir(args.output_dir)
    name_info = parse_bundle_name(args.binary_bundle)
    binary_parts, binary_files = extract_binary_parts(args.binary_bundle)

    report_workbook = find_workbook(args.report_3pd_bundle)
    report_text = read_xlsx_strings(args.report_3pd_bundle, report_workbook)
    report_parts = sorted(set(PART_RE.findall(report_text)))

    info_workbook = find_workbook(args.ecu_info_bundle)
    info_text = read_xlsx_strings(args.ecu_info_bundle, info_workbook)
    releases = RELEASE_RE.findall(info_text)
    versions = VERSION_RE.findall(info_text)

    summary = {
        'ecu': name_info['ecu'],
        'release_version': name_info['release_version'],
        'release_label': releases[0] if releases else name_info['release_version'],
        'software_version': versions[0] if versions else None,
        'binary_parts': binary_parts,
        'binary_files': binary_files,
        'report_3pd_parts': report_parts,
        'ecu_info_workbook': info_workbook,
        'report_workbook': report_workbook,
        'missing_parts_vs_3pd': sorted(set(report_parts) - set(binary_parts)),
        'extra_binary_parts_vs_3pd': sorted(set(binary_parts) - set(report_parts)),
        'source_bundles': {
            'binary_bundle': str(Path(args.binary_bundle).resolve()),
            'ecu_info_bundle': str(Path(args.ecu_info_bundle).resolve()),
            'report_3pd_bundle': str(Path(args.report_3pd_bundle).resolve()),
        },
    }
    save_json(out / 'delivery_summary.json', summary)
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
