@echo off
python "%~dp0local_bridge.py"
