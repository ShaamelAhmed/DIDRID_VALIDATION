@echo off
python "%~dp0vspy_did_rid_runner.py" rid %1 %2 --config "%~dp0vspy_operation_map.json"
