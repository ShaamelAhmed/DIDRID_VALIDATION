import argparse
import json
import socket
import subprocess
import time
from pathlib import Path


def load_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def run_command(command):
    result = subprocess.run(command, shell=True, capture_output=True, text=True)
    out = result.stdout.strip()
    return {'ok': result.returncode == 0, 'raw_response': out, 'parsed_response': out, 'notes': result.stderr.strip(), 'transport': 'command'}


def run_tcp_text_api(host, port, payload):
    with socket.create_connection((host, port), timeout=5) as sock:
        sock.sendall(payload.encode('utf-8') + b'\n')
        data = sock.recv(4096).decode('utf-8', errors='ignore').strip()
    return {'ok': True, 'raw_response': data, 'parsed_response': data, 'notes': 'tcp_text_api response', 'transport': 'tcp_text_api'}


def run_vspy_stub(kind, identifier, action='start'):
    return {'ok': False, 'raw_response': '', 'parsed_response': '', 'notes': f'Implement Vehicle Spy call for {kind} {identifier} {action}', 'transport': 'vspy_text_api'}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('kind', choices=['did', 'rid'])
    ap.add_argument('identifier')
    ap.add_argument('action', nargs='?', default='start')
    ap.add_argument('--config', required=True)
    args = ap.parse_args()

    cfg = load_json(args.config)
    entry = cfg.get(args.kind, {}).get(args.identifier, {})
    transport = entry.get('transport', 'mock')
    started = time.time()

    if transport == 'mock':
        response = entry.get('mock_response', f'{args.kind.upper()}_{args.identifier}_OK')
        payload = {
            'ok': True,
            'kind': args.kind.upper(),
            'identifier': args.identifier,
            'action': args.action,
            'raw_request': f'{args.kind}:{args.identifier}:{args.action}',
            'raw_response': response,
            'parsed_response': response,
            'notes': 'mock transport',
            'transport': 'mock',
        }
    elif transport == 'command':
        payload = run_command(entry['command'])
        payload.update({'kind': args.kind.upper(), 'identifier': args.identifier, 'action': args.action})
    elif transport == 'tcp_text_api':
        request_text = entry.get('request_template', '{kind}:{identifier}:{action}').format(kind=args.kind.upper(), identifier=args.identifier, action=args.action)
        payload = run_tcp_text_api(entry.get('host', '127.0.0.1'), int(entry.get('port', 7000)), request_text)
        payload.update({'kind': args.kind.upper(), 'identifier': args.identifier, 'action': args.action, 'raw_request': request_text})
    else:
        payload = run_vspy_stub(args.kind, args.identifier, args.action)
        payload.update({'kind': args.kind.upper(), 'identifier': args.identifier, 'action': args.action})

    payload['duration_ms'] = round((time.time() - started) * 1000, 1)
    print(json.dumps(payload))


if __name__ == '__main__':
    main()
