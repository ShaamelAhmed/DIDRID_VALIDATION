@echo off
python "%~dp0vspy_did_rid_runner.py" did %1 --config "%~dp0vspy_operation_map.json"
