import json
import subprocess
import sys
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

HOST = '127.0.0.1'
PORT = 8000
WRAPPER_DIR = Path(__file__).resolve().parent / 'wrappers'
RUNNER = WRAPPER_DIR / 'vspy_did_rid_runner.py'
OP_MAP = WRAPPER_DIR / 'vspy_operation_map.json'


def run_runner(args):
    cmd = [sys.executable, str(RUNNER), *args, '--config', str(OP_MAP)]
    result = subprocess.run(cmd, capture_output=True, text=True)
    stdout = result.stdout.strip() or '{}'
    try:
        payload = json.loads(stdout)
    except Exception:
        payload = {'ok': False, 'raw_response': stdout, 'parsed_response': '', 'notes': result.stderr.strip() or 'invalid JSON from runner'}
    payload.setdefault('exit_code', result.returncode)
    return payload


class Handler(BaseHTTPRequestHandler):
    def _send(self, status, payload):
        body = json.dumps(payload).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path == '/health':
            self._send(200, {'ok': True, 'service': 'valeo-local-bridge'})
        else:
            self._send(404, {'ok': False, 'error': 'not found'})

    def do_POST(self):
        length = int(self.headers.get('Content-Length', '0'))
        payload = json.loads(self.rfile.read(length).decode('utf-8') or '{}') if length else {}
        if self.path == '/did/read':
            res = run_runner(['did', payload.get('did', '')])
            self._send(200 if res.get('ok') else 500, res)
            return
        if self.path == '/rid/run':
            res = run_runner(['rid', payload.get('rid', ''), payload.get('action', 'start')])
            self._send(200 if res.get('ok') else 500, res)
            return
        self._send(404, {'ok': False, 'error': 'unknown endpoint'})


if __name__ == '__main__':
    server = HTTPServer((HOST, PORT), Handler)
    print(f'Bridge listening on http://{HOST}:{PORT}')
    server.serve_forever()
