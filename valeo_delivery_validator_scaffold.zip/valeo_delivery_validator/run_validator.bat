@echo off
setlocal
if "%~3"=="" (
  echo Usage: run_validator.bat ^<binary_bundle.zip^> ^<ecu_info.zip^> ^<3pd_report.zip^>
  exit /b 1
)
python scripts\ingest_delivery.py --binary-bundle "%~1" --ecu-info-bundle "%~2" --report-3pd-bundle "%~3" --output-dir deliveries\parsed\current
python scriptsuild_profile.py --summary deliveries\parsed\current\delivery_summary.json --output profiles\generated\current_profile.json
start "Valeo Local Bridge" cmd /k "python bridge\local_bridge.py"
timeout /t 2 >nul
python scriptsalidate_release.py --profile profiles\generated\current_profile.json --output-dir outputs\current_run
