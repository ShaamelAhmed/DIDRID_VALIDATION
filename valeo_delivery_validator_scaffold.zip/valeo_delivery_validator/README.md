# Valeo Delivery Validator

Simplified multi-release DID/RID black-box validator for Valeo deliveries.

## What it does
1. Ingests three Valeo bundles (Binary, ECU Info, 3PD Report)
2. Extracts release metadata and expected values
3. Builds a release-specific validation profile
4. Runs a fixed DID/RID test set through a local HTTP bridge
5. Writes JSON + CSV results

## Project flow
`deliveries -> ingest_delivery.py -> build_profile.py -> local_bridge.py -> validate_release.py -> outputs`

## Recommended VS Code flow
1. Open the `valeo_delivery_validator` folder in VS Code.
2. Open a terminal in the project root.
3. Run the bridge in terminal 1:
   `python bridge/local_bridge.py`
4. In terminal 2 run:
   `python scripts/ingest_delivery.py --binary-bundle <zip> --ecu-info-bundle <zip> --report-3pd-bundle <zip> --output-dir deliveries/parsed/sample`
5. Build the profile:
   `python scripts/build_profile.py --summary deliveries/parsed/sample/delivery_summary.json --output profiles/generated/sample_profile.json`
6. Validate:
   `python scripts/validate_release.py --profile profiles/generated/sample_profile.json --output-dir outputs/sample_run`

## Current state
- The validator path is fully runnable.
- The VSpy runner currently defaults to mock responses for safe local testing.
- The next real integration point is `bridge/wrappers/vspy_did_rid_runner.py`.
